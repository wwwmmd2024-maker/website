# IR-Jalali — Website Operating System

> **نسخه هسته:** ۱٫۰٫۰ (Milestone 1 — Foundation)
> **وضعیت:** ✅ نصب واقعی، تست‌شده (۸۴ تست خودکار + تست End-to-End کامل)

IR-Jalali یک **سیستم‌عامل وب‌سایت** است؛ نه یک قالب و نه یک CMS ساده.
هدف: ساخت تقریباً هر نوع وب‌سایت (شرکتی، فروشگاهی، خبری، آموزشی، رزرواسیون، …)
**بدون تغییر Core** — فقط با Theme، Plugin، Module، Block و Widget.

```
CORE = PLATFORM      THEME = DESIGN        PLUGIN = FUNCTIONALITY
MODULE = FEATURE     BLOCK = UI COMPONENT  TEMPLATE = STRUCTURE
CONTENT = DATA       API = COMMUNICATION
```

---

## ۱. پیش‌نیازها (Production)

| نیاز | مقدار |
|---|---|
| PHP | 8.2+ (تست‌شده با 8.4) |
| دیتابیس | MySQL 8+ / MariaDB 10.6+ |
| وب‌سرور | Apache 2.4 (+mod_rewrite) یا Nginx |
| اکستنشن اجباری | pdo, pdo_mysql, mbstring, json, fileinfo |
| اکستنشن اختیاری | curl, gd (تامبنیل)، intl، zip |
| هاست | سازگار با Shared Hosting + cPanel، بدون نیاز به Composer/Node در Production |

## ۲. نصب روی cPanel (تولیدی)

1. محتوای پوشه را در هاست آپلود کنید (مثلاً `public_html/ir-jalali`).
2. **DocumentRoot دامنه را روی `.../ir-jalali/public` بگذارید.**
   اگر هاست اجازه نمی‌دهد، از `.htaccess` ریشه استفاده کنید (داخل فایل توضیح داده شده).
3. در cPanel یک دیتابیس MySQL + کاربر بسازید.
4. مرورگر را باز کنید: `https://domain.com/install`
5. ویزارد را طی کنید: پیش‌نیازها ← دیتابیس ← مدیر ← سایت ← اتمام.
6. نصب‌کننده **قفل می‌شود** (فایل `storage/install.lock`) و کلید امنیتی ساخته می‌شود.
7. وارد `/admin` شوید و **راه‌اندازی اولیه** (انتخاب نوع سایت) را انجام دهید.
8. کرون cPanel (هر دقیقه) برای انتشار زمان‌بندی‌شده و نگهداری:
   ```
   php /home/USER/ir-jalali/cron.php >/dev/null 2>&1
   ```

## ۳. اجرای محلی (توسعه)

```bash
cp .env.example .env          # سپس مقادیر DB را ویرایش کنید
php -S 127.0.0.1:8000 router.php
# مرورگر: http://127.0.0.1:8000/install
php tests/smoke.php           # اجرای ۸۴ تست خودکار
```

## ۴. ساختار

```
public/          فرانت‌کنترلر + assets (تنها نقطه ورود وب)
core/            هسته مستقل (Kernel, Http, Database, Security, Date, ...)
app/             لایه اپلیکیشن (Controllers, Services, Repositories, Views, ...)
config/          کانفیگ محیطی (مقادیر از .env)
database/        مایگریشن‌ها (MySQL + SQLite-dev) و سیدرها
languages/       fa_IR (پیش‌فرض، RTL) و en_US
storage/         logs / cache / uploads (قابل نوشتن)
themes/ plugins/ modules/ blocks/ widgets/ templates/   ← موتورهای Part 2
docs/            معماری، ERD، اسکیما، امنیت، نقشه راه
tests/           تست خودکار
cron.php         ورودی زمان‌بند (کرون)
```

## ۵. چه چیزی در Milestone 1 کار می‌کند (واقعی، تست‌شده)

- ✅ Web Installer چهار مرحله‌ای + قفل نصب + ساخت APP_KEY
- ✅ Setup Wizard با ۱۴ نوع وب‌سایت (برگه، فهرست، قالب، حالت واقعی می‌سازد)
- ✅ احراز هویت + RBAC کامل (۶ نقش، ۲۴ دسترسی، enforce در بک‌اند)
- ✅ تقویم شمسی Pure-PHP (راستی‌آزمایی‌شده با Intl در بازه ۱۹۲۵–۲۰۳۰) + abstraction تقویم
- ✅ کتابخانه رسانه امن (اعتبارسنجی MIME/محتوا، تامبنیل، حذف واقعی)
- ✅ موتور محتوا (Post/Page، متا، تاکسونومی، منو، بازبینی، قالب داده‌ای)
- ✅ ۴۶ جدول Core با کلید خارجی، ایندکس و Soft Delete
- ✅ زمان‌بند + صف + انتشار زمان‌بندی‌شده (کرون واقعی)
- ✅ REST API نسخه ۱ (توکن Bearer، Throttle)
- ✅ لاگ چندکاناله + Log Viewer + حسابرسی + لاگ امنیتی
- ✅ CSRF، Rate Limit، Security Headers، CSP، Session Hardening

مستندات کامل: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) ·
[`docs/ERD.md`](docs/ERD.md) · [`docs/DATABASE_SCHEMA.md`](docs/DATABASE_SCHEMA.md) ·
[`docs/SECURITY.md`](docs/SECURITY.md) · [`docs/ROADMAP.md`](docs/ROADMAP.md)
