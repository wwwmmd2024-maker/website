/* IR-Jalali admin helpers (vanilla JS, no dependencies). */
(function () {
  'use strict';

  // Confirm destructive forms.
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!window.confirm(form.getAttribute('data-confirm'))) {
        e.preventDefault();
      }
    });
  });

  // Media drag & drop upload.
  var drop = document.getElementById('dropzone');
  var input = document.getElementById('fileinput');
  if (!drop || !input) return;

  var token = drop.getAttribute('data-token') || '';
  var status = document.getElementById('upload-status');

  drop.addEventListener('click', function () { input.click(); });
  input.addEventListener('change', function () { upload(input.files); input.value = ''; });

  ['dragenter', 'dragover'].forEach(function (ev) {
    drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); });
  });
  ['dragleave', 'drop'].forEach(function (ev) {
    drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); });
  });
  drop.addEventListener('drop', function (e) {
    if (e.dataTransfer && e.dataTransfer.files.length) upload(e.dataTransfer.files);
  });

  function upload(files) {
    if (!files.length) return;
    var fd = new FormData();
    for (var i = 0; i < files.length && i < 10; i++) fd.append('files[]', files[i]);
    fd.append('_token', token);
    status.textContent = 'در حال بارگذاری...';
    fetch('/admin/media/upload', {
      method: 'POST',
      body: fd,
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (res.ok) {
          window.location.reload();
        } else {
          status.textContent = (res.errors && res.errors.join(' | ')) || 'خطا در بارگذاری';
        }
      })
      .catch(function () { status.textContent = 'خطای ارتباط با سرور'; });
  }
})();
