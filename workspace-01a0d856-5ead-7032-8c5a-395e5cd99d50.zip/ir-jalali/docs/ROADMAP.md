# IR-Jalali — Roadmap

## ✅ Milestone 1 — Foundation (تمام‌شده، تست‌شده)

- معماری Core (Kernel/DI/Config/Http/Database/Events/Hooks)
- ۴۶ جدول + مایگریشن دو درایوری + سیدر
- Web Installer + Setup Wizard (۱۴ نوع سایت) + قفل نصب
- Auth + RBAC واقعی + Rate Limit + Audit
- Date abstraction + جلالی Pure-PHP (تأیید با Intl)
- i18n (fa_IR/en_US) + RTL
- Media Manager امن + تامبنیل
- Scheduler + Queue + Cron + انتشار زمان‌بندی‌شده
- REST API v1 (status + posts + توکن)
- Admin: داشبورد، تنظیمات، کاربران، لاگ‌ها، رسانه
- ۸۴ تست خودکار + E2E کامل (نصب تا API)

## ◻️ Milestone 2 — Visual Builder & Engines (بخش دوم مسترپرامپت)

- `ThemeManager` + قرارداد `theme.json` + رندر فرانت از قالب فعال
- `PluginManager`: نصب/فعال‌سازی، وابستگی، `plugin.json`، هوک‌های lifecycle
- `ModuleManager` + اتصال به Website Mode
- `BlockManager` + Visual Page Builder (درگ‌ودراپ، بلاک‌های Core)
- `WidgetManager` + سایدبارها
- Template Engine + Dynamic Data + Revisions UI (compare/restore)
- CPT Builder + Custom Field Builder (UI کامل ادمین)
- Menu Builder (درگ‌ودراپ + مگامنو) + Form Builder
- Media: پوشه‌ها، جایگزینی، WebP/AVIF خودکار
- Marketplace-ready: امضای بسته، آپدیت یک‌کلیکی، مخزن

## ◻️ Milestone 3 — Modules & Scale

- ماژول‌های E-Commerce، Booking، Education، Membership (روی همان Core)
- چندزبانگی محتوا + چندسایتی
- کش صفحه/فرگمنت + Redis driver + Object cache
- 2FA، Database sessions، WAF rules
- CLI (`irj` command) + Backup Manager UI
- تست E2E مرورگری + CI
