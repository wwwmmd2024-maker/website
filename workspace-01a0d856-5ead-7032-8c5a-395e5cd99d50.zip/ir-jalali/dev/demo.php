<?php

/**
 * DEV-ONLY: seed demo content (pages, posts, menu). Usage: php dev/demo.php
 */
require '/home/user/ir-jalali/core/Kernel/Autoloader.php';
IRJalali\Core\Kernel\Autoloader::register('/home/user/ir-jalali');
$app = IRJalali\Core\Kernel\Application::boot('/home/user/ir-jalali');
$posts = $app->make(IRJalali\App\Repositories\PostRepository::class);
$menus = $app->make(IRJalali\App\Repositories\MenuRepository::class);

$pages = [
    ['title' => 'خانه', 'slug' => 'home', 'content' => '<p>به سایت من خوش آمدید.</p>'],
    ['title' => 'درباره ما', 'slug' => 'about', 'content' => '<p>این صفحه درباره است.</p>'],
    ['title' => 'تماس', 'slug' => 'contact', 'content' => '<p>با ما در تماس باشید.</p>'],
];
foreach ($pages as $page) {
    if (!$posts->slugExists('page', $page['slug'])) {
        $posts->create($page + ['post_type' => 'page', 'status' => 'published', 'author_id' => 1, 'published_at' => date('Y-m-d H:i:s')]);
        echo "page: {$page['slug']}\n";
    }
}
$blog = [
    ['title' => 'نخستین نوشته', 'slug' => 'first-post', 'content' => '<p>سلام دنیا!</p>'],
    ['title' => 'دومین نوشته', 'slug' => 'second-post', 'content' => '<p>نوشته دوم.</p>'],
];
foreach ($blog as $post) {
    if (!$posts->slugExists('post', $post['slug'])) {
        $posts->create($post + ['post_type' => 'post', 'status' => 'published', 'author_id' => 1, 'published_at' => date('Y-m-d H:i:s')]);
        echo "post: {$post['slug']}\n";
    }
}
$menuId = $menus->createMenu('main', 'فهرست اصلی', 'primary');
echo "menu: $menuId\n";
if ($menus->flatItems($menuId) === []) {
    $home = $posts->adminList('page', 1, 0, 'خانه');
    $about = $posts->adminList('page', 1, 0, 'درباره ما');
    if (isset($home[0])) {
        $menus->addItem($menuId, ['title' => 'خانه', 'type' => 'page', 'url' => '/home', 'reference_type' => 'page', 'reference_id' => $home[0]->id, 'ordering' => 1]);
    }
    if (isset($about[0])) {
        $menus->addItem($menuId, ['title' => 'درباره ما', 'type' => 'page', 'url' => '/about', 'reference_type' => 'page', 'reference_id' => $about[0]->id, 'ordering' => 2]);
    }
    echo "menu items added\n";
}
