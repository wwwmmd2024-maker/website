<?php

declare(strict_types=1);

use IRJalali\App\Controllers\Admin\DashboardController;
use IRJalali\App\Controllers\Admin\BuilderController;
use IRJalali\App\Controllers\Admin\FormController;
use IRJalali\App\Controllers\Admin\LogController;
use IRJalali\App\Controllers\Admin\MediaController;
use IRJalali\App\Controllers\Admin\MenuController;
use IRJalali\App\Controllers\Admin\PageController;
use IRJalali\App\Controllers\Admin\PluginPageController;
use IRJalali\App\Controllers\Admin\PostController as AdminPostController;
use IRJalali\App\Controllers\Admin\SettingsController;
use IRJalali\App\Controllers\Admin\TemplateController;
use IRJalali\App\Controllers\Admin\UserController;
use IRJalali\App\Controllers\PublicFormController;
use IRJalali\App\Controllers\Api\PostController as ApiPostController;
use IRJalali\App\Controllers\Api\StatusController;
use IRJalali\App\Controllers\AuthController;
use IRJalali\App\Controllers\FrontController;
use IRJalali\App\Controllers\HomeController;
use IRJalali\App\Controllers\ThemeAssetController;
use IRJalali\App\Controllers\InstallController;
use IRJalali\App\Controllers\SetupController;
use IRJalali\App\Middleware\ApiAuthenticate;
use IRJalali\App\Middleware\ApiThrottle;
use IRJalali\App\Middleware\Authenticate;
use IRJalali\App\Middleware\Guest;
use IRJalali\App\Middleware\RequireInstalled;
use IRJalali\App\Middleware\RequireNotInstalled;
use IRJalali\App\Middleware\SecurityHeaders;
use IRJalali\App\Middleware\StartSession;
use IRJalali\App\Middleware\VerifyCsrf;
use IRJalali\Core\Http\Router;

/** @var Router $router */

$web = [StartSession::class, SecurityHeaders::class];

// ── Installer (only before install) ──────────────────────────────
$router->group(['middleware' => [...$web, RequireNotInstalled::class]], function (Router $r): void {
    $r->get('/install', [InstallController::class, 'index'])->name('install');
    $r->post('/install', [InstallController::class, 'store'])
        ->middleware(VerifyCsrf::class)->name('install.store');
});

// ── First-run setup wizard ───────────────────────────────────────
$router->group(['middleware' => [...$web, RequireInstalled::class, Authenticate::class]], function (Router $r): void {
    $r->get('/setup', [SetupController::class, 'index'])->name('setup');
    $r->post('/setup', [SetupController::class, 'apply'])
        ->middleware(VerifyCsrf::class)->name('setup.apply');
});

// ── Admin ────────────────────────────────────────────────────────
$router->group(['prefix' => 'admin', 'middleware' => [...$web, RequireInstalled::class]], function (Router $r): void {
    $r->get('/login', [AuthController::class, 'showLogin'])->middleware(Guest::class)->name('login');
    $r->post('/login', [AuthController::class, 'login'])->middleware(Guest::class, VerifyCsrf::class)->name('login.store');
    $r->post('/logout', [AuthController::class, 'logout'])->middleware(Authenticate::class, VerifyCsrf::class)->name('logout');

    $r->get('', [DashboardController::class, 'index'])->middleware(Authenticate::class)->name('admin');
    $r->get('/', [DashboardController::class, 'index'])->middleware(Authenticate::class);

    $r->get('/settings', [SettingsController::class, 'index'])->middleware(Authenticate::class)->name('admin.settings');
    $r->post('/settings', [SettingsController::class, 'update'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/users', [UserController::class, 'index'])->middleware(Authenticate::class)->name('admin.users');
    $r->get('/logs', [LogController::class, 'index'])->middleware(Authenticate::class)->name('admin.logs');

    $r->get('/media', [MediaController::class, 'index'])->middleware(Authenticate::class)->name('admin.media');
    $r->post('/media/upload', [MediaController::class, 'upload'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/media/{id}/delete', [MediaController::class, 'destroy'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/pages', [PageController::class, 'index'])->middleware(Authenticate::class)->name('admin.pages');
    $r->get('/pages/create', [PageController::class, 'create'])->middleware(Authenticate::class);
    $r->post('/pages', [PageController::class, 'store'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/pages/{id}/edit', [PageController::class, 'edit'])->middleware(Authenticate::class);
    $r->post('/pages/{id}', [PageController::class, 'update'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/pages/{id}/delete', [PageController::class, 'destroy'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/posts', [AdminPostController::class, 'index'])->middleware(Authenticate::class)->name('admin.posts');
    $r->get('/posts/create', [AdminPostController::class, 'create'])->middleware(Authenticate::class);
    $r->post('/posts', [AdminPostController::class, 'store'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/posts/{id}/edit', [AdminPostController::class, 'edit'])->middleware(Authenticate::class);
    $r->post('/posts/{id}', [AdminPostController::class, 'update'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/posts/{id}/delete', [AdminPostController::class, 'destroy'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/templates', [TemplateController::class, 'index'])->middleware(Authenticate::class)->name('admin.templates');
    $r->get('/templates/create', [TemplateController::class, 'create'])->middleware(Authenticate::class);
    $r->post('/templates', [TemplateController::class, 'store'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/templates/{id}/edit', [TemplateController::class, 'edit'])->middleware(Authenticate::class);
    $r->post('/templates/{id}', [TemplateController::class, 'update'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/templates/{id}/delete', [TemplateController::class, 'destroy'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/menus', [MenuController::class, 'index'])->middleware(Authenticate::class)->name('admin.menus');
    $r->post('/menus', [MenuController::class, 'store'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/menus/{id}/edit', [MenuController::class, 'edit'])->middleware(Authenticate::class);
    $r->post('/menus/{id}', [MenuController::class, 'update'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/menus/{id}/delete', [MenuController::class, 'destroy'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/menus/{id}/items', [MenuController::class, 'storeItem'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/menus/{id}/items/{item}', [MenuController::class, 'updateItem'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/menus/{id}/items/{item}/delete', [MenuController::class, 'destroyItem'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/forms', [FormController::class, 'index'])->middleware(Authenticate::class)->name('admin.forms');
    $r->get('/forms/create', [FormController::class, 'create'])->middleware(Authenticate::class);
    $r->post('/forms', [FormController::class, 'store'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/forms/{id}/edit', [FormController::class, 'edit'])->middleware(Authenticate::class);
    $r->post('/forms/{id}', [FormController::class, 'update'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/forms/{id}/delete', [FormController::class, 'destroy'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/forms/{id}/fields', [FormController::class, 'fields'])->middleware(Authenticate::class);
    $r->post('/forms/{id}/fields', [FormController::class, 'storeField'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/forms/{id}/fields/{field}/delete', [FormController::class, 'destroyField'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/forms/{id}/fields/{field}/move', [FormController::class, 'moveField'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/forms/{id}/submissions', [FormController::class, 'submissions'])->middleware(Authenticate::class);
    $r->get('/forms/{id}/submissions/{submission}', [FormController::class, 'showSubmission'])->middleware(Authenticate::class);
    $r->post('/forms/{id}/submissions/{submission}/delete', [FormController::class, 'destroySubmission'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/plugin/{slug}', [PluginPageController::class, 'show'])->middleware(Authenticate::class)->name('admin.plugin');
    $r->post('/plugin/{slug}', [PluginPageController::class, 'show'])->middleware(Authenticate::class, VerifyCsrf::class);

    $r->get('/builder/{entity}/{id}', [BuilderController::class, 'editor'])->middleware(Authenticate::class)->name('admin.builder');
    $r->get('/api/builder/load', [BuilderController::class, 'apiLoad'])->middleware(Authenticate::class);
    $r->post('/api/builder/save', [BuilderController::class, 'apiSave'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->post('/api/builder/preview', [BuilderController::class, 'apiPreview'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/api/builder/revisions', [BuilderController::class, 'apiRevisions'])->middleware(Authenticate::class);
    $r->get('/api/builder/revision', [BuilderController::class, 'apiRevision'])->middleware(Authenticate::class);
    $r->post('/api/builder/restore', [BuilderController::class, 'apiRestore'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/api/builder/tokens', [BuilderController::class, 'apiTokens'])->middleware(Authenticate::class);
    $r->post('/api/builder/tokens', [BuilderController::class, 'apiTokensSave'])->middleware(Authenticate::class, VerifyCsrf::class);
    $r->get('/api/builder/media', [BuilderController::class, 'apiMedia'])->middleware(Authenticate::class);
});

// ── REST API v1 ──────────────────────────────────────────────────
$router->group(['prefix' => 'api/v1', 'middleware' => [SecurityHeaders::class, RequireInstalled::class, ApiThrottle::class]], function (Router $r): void {
    $r->get('/status', [StatusController::class, 'show'])->name('api.status');
    $r->get('/posts', [ApiPostController::class, 'index'])->middleware(ApiAuthenticate::class)->name('api.posts');
});

// ── Theme assets (jailed proxy; themes live outside docroot) ─────────
$router->group(['middleware' => [...$web, RequireInstalled::class]], function (Router $r): void {
    $r->get('/theme-assets/{theme}/{file*}', [ThemeAssetController::class, 'show'])->name('theme.asset');
});

// ── Frontend (theme engine) ──────────────────────────────────────
$router->group(['middleware' => [...$web, RequireInstalled::class]], function (Router $r): void {
    $r->get('/', [FrontController::class, 'index'])->name('home');
    $r->get('/search', [FrontController::class, 'search'])->name('search');
    $r->post('/forms/submit', [PublicFormController::class, 'submit'])->middleware(VerifyCsrf::class)->name('forms.submit');
    $r->post('/newsletter/subscribe', [PublicFormController::class, 'newsletter'])->middleware(VerifyCsrf::class)->name('newsletter.subscribe');
});

// ── Plugin routes (after specific core routes, before catch-all) ──
require __DIR__ . '/plugin-routes.php';

// ── Catch-all MUST stay last: explicit routes beat post slugs ─────
$router->group(['middleware' => [...$web, RequireInstalled::class]], function (Router $r): void {
    $r->get('/{slug}', [FrontController::class, 'page'])->name('page');
});
