<?php

declare(strict_types=1);

namespace IRJalali\App\Middleware;

use Closure;
use IRJalali\Core\Http\Middleware;
use IRJalali\Core\Http\Request;
use IRJalali\Core\Http\Response;
use IRJalali\Core\Security\Session;

final class StartSession implements Middleware
{
    public function handle(Request $request, Closure $next): Response
    {
        Session::start();

        return $next($request);
    }
}
