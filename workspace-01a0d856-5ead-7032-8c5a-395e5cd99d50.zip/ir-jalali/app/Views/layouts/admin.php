<?php
/** @var \IRJalali\Core\Translation\Translator $t */
$rtl = $t->isRtl();
$active = $active ?? 'dashboard';
$user = $user ?? null;
$nav = [
    'dashboard' => ['url' => '/admin', 'label' => $t->get('nav.dashboard'), 'icon' => '◈'],
    'pages' => ['url' => '/admin/pages', 'label' => $t->get('nav.pages'), 'icon' => '▤'],
    'posts' => ['url' => '/admin/posts', 'label' => $t->get('nav.posts'), 'icon' => '✎'],
    'templates' => ['url' => '/admin/templates', 'label' => $t->get('nav.templates'), 'icon' => '▦'],
    'menus' => ['url' => '/admin/menus', 'label' => $t->get('nav.menus'), 'icon' => '☰'],
    'forms' => ['url' => '/admin/forms', 'label' => $t->get('nav.forms'), 'icon' => '⧉'],
    'media' => ['url' => '/admin/media', 'label' => $t->get('nav.media'), 'icon' => '◉'],
    'users' => ['url' => '/admin/users', 'label' => $t->get('nav.users'), 'icon' => '⦿'],
    'logs' => ['url' => '/admin/logs', 'label' => $t->get('nav.logs'), 'icon' => '☰'],
    'settings' => ['url' => '/admin/settings', 'label' => $t->get('nav.settings'), 'icon' => '⚙'],
];
?>
<!DOCTYPE html>
<html lang="<?= $t->locale() === 'fa_IR' ? 'fa' : 'en' ?>" dir="<?= $rtl ? 'rtl' : 'ltr' ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? $t->get('nav.dashboard')) ?> — <?= e($t->get('app.name')) ?></title>
<link rel="stylesheet" href="/assets/css/admin.css">
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="brand"><span class="mark">آ</span><span><?= e($t->get('app.name')) ?></span></div>
    <nav>
      <?php foreach ($nav as $key => $item): ?>
        <a href="<?= e($item['url']) ?>" class="<?= $key === $active ? 'active' : '' ?>"><span class="ic"><?= e($item['icon']) ?></span><?= e($item['label']) ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="side-foot">
      <a href="/" target="_blank" rel="noopener">↗ <?= e($t->get('nav.view_site')) ?></a>
    </div>
  </aside>
  <div class="main">
    <header class="topbar">
      <strong><?= e($title ?? '') ?></strong>
      <div class="userbox">
        <?php if ($user): ?><span class="avatar"><?= e(mb_substr((string) ($user['display_name'] ?? $user['username']), 0, 1, 'UTF-8')) ?></span><span><?= e($user['display_name'] ?? $user['username']) ?></span><?php endif; ?>
        <form method="post" action="/admin/logout" style="display:inline"><?= $csrf->field() ?? '' ?><button class="link" type="submit"><?= e($t->get('nav.logout')) ?></button></form>
      </div>
    </header>
    <?php if (!empty($flash)): ?>
      <div class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
    <?php endif; ?>
    <div class="content">
      <?= $sections['content'] ?? '' ?>
    </div>
  </div>
</div>
<script src="/assets/js/admin.js"></script>
</body>
</html>
